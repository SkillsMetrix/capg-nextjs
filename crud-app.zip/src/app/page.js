import React from 'react';
import MainApp from './components/MainApp';

function page(props) {
    return (
        <div>
          <MainApp/>
        </div>
    );
}

export default page;