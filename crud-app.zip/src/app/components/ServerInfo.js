
 
export default async function ServerInfo() {

    const time =new Date().toLocaleString()

    return (
        <div style={{padding:"20px",border:"1px solid gray"}}>
            <h2>Server Component</h2>
            <p>Rendered at:</p>
            <strong>{time}</strong>
        </div>
    )
    
}