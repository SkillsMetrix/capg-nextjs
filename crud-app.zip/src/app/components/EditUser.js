import React from 'react';

function EditUser(props) {
    return (
        <div>
            
        </div>
    );
}

export default EditUser;