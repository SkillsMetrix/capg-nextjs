import React from 'react';
import Header from './Header';
import Footer from './Footer';

function MainApp(props) {
    return (
        <div>
            <Header/>
            <p>User CRUD App</p>
            <Footer/>
        </div>
    );
}

export default MainApp;