export async function getProducts() {
  const response = await fetch("http://localhost:3001/products", {
    cache: "no-store",
  });

  return await response.json();
}
export async function addProduct(product) {
  await fetch("http://localhost:3001/products", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(product),
  });
  return await response.json();
}
