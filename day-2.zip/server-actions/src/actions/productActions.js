'use server'
import { addProduct } from "@/services/productService"


export async function saveProduct(formData){
    const product= {
        name: formData.get("name"),
        price: Number(formData.get("price"))
    }
    await addProduct(product)
    //revalidatePath("/products")
}