'use client'
 
import { saveProduct } from "@/actions/productActions";
import React, { useState } from "react";

function ProductForm(props) {
/*   const [name, setName] = useState("");
  const [price, setPrice] = useState("");

  async function saveProductLocal() {
    await saveProduct({
      name,
      price: Number(price),
    });
    alert("product added");
    setName("");
    setPrice("");
  } */
  return <div>

    <p>Product Application</p>
    <form onSubmit={saveProduct}>
    <input placeholder="Enter Product name" name="name"/>
    <input placeholder="Enter Product price" name="price"/>
    <br/>
    <button>Add Product</button>
    </form>
  </div>;
}

export default ProductForm;
