import { logger } from "@/middlewares/logger";
import { auth } from "./middlewares/auth";

export function middleware(request) {
  console.log("Inside Middleware");
  // logging middleware
  logger(request);

  //auth middleware
 /*  const response = auth(request);
  if (response.status !== 200) {
    return response;
  }
  console.log("Auth Sucessfull");
  return response;
}

export const config = {
  matcher: ["/api/products/:path*"],
}; */
}
