import { apiErrorHandler } from "@/lib/apiErrorHandler";
import { NextResponse } from "next/server";

const BASE_URL = "http://localhost:3001";

export async function GET() {
  try {
    const response = await fetch(`${BASE_URL}/products`);
    if (!response.ok) {
      throw new Error("Unable to fetch Products");
    }
    const data = await response.json();
    return NextResponse.json(data);
  } catch (error) {
    return apiErrorHandler(error,"Unable to Fetch Products")
    
    
  }
}

export async function POST(request) {
  const body = await request.json();

  const response = await fetch(`${BASE_URL}/products`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });

  const data = await response.json();
  return NextResponse.json(data, { status: 201 });
}
