'use client'

import React from 'react';

function Error({error,reset}) {
    return (
        <div>
            <h2>Something went wrong</h2>
            <p>{error.message}</p>
        </div>
    );
}

export default Error;