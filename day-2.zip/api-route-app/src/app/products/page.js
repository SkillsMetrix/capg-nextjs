 

function ProductPAge() {
    if(Math.random() > 0.5){
    throw new Error("unable to load products")
    }
    return (
        <div>
            <h1>Products page</h1>
        </div>
    );
}

export default ProductPAge;