import React from 'react';
import styles from '../styles/App.module.css'
function Header(props) {
    return (
        <div>
            <h2 className={styles.title}>{props.hm}</h2>
        </div>
    );
}

export default Header;