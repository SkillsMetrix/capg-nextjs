import React from 'react';
import User from './User';
import styles from "../styles/App.module.css";
function Users({users,onRequestEdit,onDelete}) {
    if(!users.length) return <div className={styles.empty}>No Users Found Yet</div>
    return (
        <div>
            <h3> Users Data</h3>
            <div className={styles.list}>
                {users.map(u => (
                     <User user={u} key={u.id} onRequestEdit={onRequestEdit} ord={onDelete}/>
                ))}
            </div>
                    
        </div>
    );
}

export default Users;