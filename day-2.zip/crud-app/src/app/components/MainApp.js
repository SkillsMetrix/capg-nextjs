'use client'
import React, { useState } from "react";
import Header from "./Header";
import Footer from "./Footer";
import styles from "../styles/App.module.css";
import AddUser from "./AddUser";
import { useUsers } from "../hooks/useUsers";
import Users from "./Users";
import EditUser from "./EditUser";

function MainApp(props) {
  const {addUser,users,deleteUser,clearAll,updateUser}= useUsers()
  const [editing,setEditing]=useState(null)
  const handleRequestEdit=(user) => setEditing(user)
  const handleCancelEdit =() => setEditing(null)
  const handleSaveEdit=(id,patch) =>{
    updateUser(id,patch)
    setEditing(null)
  }
  const headerMessage = "NextJS User Portfolio App";
  const footerMessage = " User CopyRight";
  return (
    <div>
      <Header hm={headerMessage} />
      <main className={styles.container}>
        <div className={styles.grid}>
          <div className={styles.card}>
            <AddUser onAdd={addUser}/>
          </div>
          <div className={styles.card}>
            {editing ? (
              <div>
                <h3>Edit User</h3>
                <EditUser user={editing} onSave={handleSaveEdit} onCancel={handleCancelEdit}/>
              </div>
            ):(
            <Users users={users} onRequestEdit={handleRequestEdit} onDelete={deleteUser} onClearAll={clearAll}/>
            )}
          </div>
        </div>
      </main>
      <Footer fm={footerMessage} />
    </div>
  );
}

export default MainApp;
