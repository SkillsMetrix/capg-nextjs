'use client'
import React, { useState } from 'react';
import styles from '../styles/App.module.css'
function AddUser({onAdd}) {

    const [username,setUsername]= useState('')
     const [email,setEmail]= useState('')
      const [city,setCity]= useState('')
    
      const reset=()=>{
        setUsername("")
        setEmail("")
        setCity("")
      }

  const handleSubmit=(e)=> {
    e.preventDefault();
    if(!username.trim() || !email.trim() || !city.trim()) return alert("All fields Required")
    onAdd({username:username.trim(),email:email.trim(),city:city.trim()})
    reset()
  }
    return (
       <form onSubmit={handleSubmit} className={styles.form}>
        <h3>Add User</h3>
        <input placeholder='Enter UserName' type='text' value={username} onChange={e => setUsername(e.target.value)} className={styles.input}/>
         <input placeholder='Enter Email' type='text' value={email} onChange={e => setEmail(e.target.value)} className={styles.input}/>
         <input placeholder='Enter City' type='text' value={city} onChange={e => setCity(e.target.value)} className={styles.input}/>
         <div className={styles.controls}>
            <button className={styles.button}>Add User</button>
             <button className={styles.button}>Reset</button>
         </div>
       </form>
    );
}

export default AddUser;