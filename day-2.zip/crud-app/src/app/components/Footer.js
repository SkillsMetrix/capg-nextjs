import React from 'react';
import styles from '../styles/App.module.css'
function Footer(props) {
    return (
        <div>
            
        </div>
    );
}

export default Footer;