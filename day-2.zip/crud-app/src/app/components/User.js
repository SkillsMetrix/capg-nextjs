import React from 'react';
import styles from "../styles/App.module.css";
function User({user,onRequestEdit,ord}) {
    return (
        <div className={styles.item}>
            <div>
                <strong>{user.username}</strong> - {user.email} - {user.city}
            </div>
            <div className={styles.itemControls}>
            
                <button onClick={()=> onRequestEdit(user)} className={styles.small}>Edit</button>
                 <button onClick={()=> ord(user.id)} className={styles.dangerSmall}>Delete</button>
            </div>
            </div>
        
    );
}

export default User;