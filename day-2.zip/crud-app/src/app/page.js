import React from 'react';
import MainApp from './components/MainApp';
import CompanyInfo from './server/CompanyInfo';
import ProjectInfo from './server/ProjectInfo';

function page(props) {
    return (
        <div>
          <MainApp/>
          <hr/>
          <CompanyInfo/>
          <hr/>
          <ProjectInfo/>
        </div>
    );
}

export default page;