
export default function CompanyInfo(){
    return(
        <>
        <h2>Company Name: {process.env.COMPANY_NAME}</h2>
         <h2>Location:  {process.env.COMPANY_LOCATION}</h2>
          <h2>Name: {process.env.TRAINER_NAME}</h2>
        </>
    )
}