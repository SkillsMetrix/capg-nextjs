import fs from "fs/promises"
import path from 'path'

export default async function ProjectInfo(){
    const file= await fs.readFile(
        path.join(process.cwd(),"package.json"),"utf8"
    )

    const pkg= JSON.parse(file)

    return(
        <div>
            <h3>{pkg.name}</h3>
            <h4>{pkg.version}</h4>
        </div>
    )
}