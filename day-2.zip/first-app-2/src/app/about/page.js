import RestApp from "@/app/frontcomp/RestApp";
import ServerInfo from "@/app/frontcomp/ServerInfo";

 

export default function About(){

    return (
        <>
        <h1>About Page</h1>
        <RestApp/>
        <hr/>
        <ServerInfo/>
       
        </>
    )
}