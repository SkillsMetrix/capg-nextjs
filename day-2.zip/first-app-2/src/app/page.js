import MainApp from "@/app/frontcomp/MainApp";

 

export default function Home(){

    return (
        <>
        <h1>User Application</h1>
         <MainApp/>
        </>
    )
}