import React from 'react';

function MainApp(props) {
    return (
        <div>
            
        </div>
    );
}

export default MainApp;