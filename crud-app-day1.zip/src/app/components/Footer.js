import React from 'react';
import styles from '../styles/App.module.css'
function Footer(props) {
    return (
        <div>
            <p>{props.fm}</p>
        </div>
    );
}

export default Footer;