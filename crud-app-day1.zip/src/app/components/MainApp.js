'use client'
import React from "react";
import Header from "./Header";
import Footer from "./Footer";
import styles from "../styles/App.module.css";
import AddUser from "./AddUser";
import { useUsers } from "../hooks/useUsers";

function MainApp(props) {
  const {addUser}= useUsers()
  const headerMessage = "NextJS User Portfolio App";
  const footerMessage = " User CopyRight";
  return (
    <div>
      <Header hm={headerMessage} />
      <main className={styles.container}>
        <div className={styles.grid}>
          <div className={styles.card}>
            <AddUser onAdd={addUser}/>
          </div>
        </div>
      </main>
      <Footer fm={footerMessage} />
    </div>
  );
}

export default MainApp;
