import Link from 'next/link'
import styles from './Navigation.module.css'


export default function Navigation(){
    return(
    <nav className={styles.navBar} aria-label='Main navigaion'>
        <ul className={styles.navList}>
            <li className={styles.navItem}>
                <Link href="/" className={styles.link}>Home</Link> | {" "}
            </li>

             <li className={styles.navItem}>
                <Link href="/about" className={styles.link}>About</Link> | {" "}
            </li>

            <li className={styles.navItem}>
                <span className={styles.link} tabIndex={0}>Services</span>
                <ul className={styles.dropdown} role='menu' aria-label='Service submenu'>
                    <li>
                        <Link href="/services/web" className={styles.dropdownItem}>Web Development</Link>
                    </li>
                    <li>
                        <Link href="/services/mobile" className={styles.dropdownItem}>Mobile Development</Link>
                    </li>
                    <li>
                        <Link href="/services/cloud" className={styles.dropdownItem}>Cloud Development</Link>
                    </li>
                </ul>
            </li>

        </ul>
    </nav>
    )
}