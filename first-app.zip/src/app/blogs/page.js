
 

export default  function SlugHome(){

    return (
        <>
        <h1>Slug Home Page</h1>
        
        </>
    )
}