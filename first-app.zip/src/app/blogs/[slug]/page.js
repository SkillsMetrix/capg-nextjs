// server side comp

 

export default async function UserBlogs({params}){
 
    const {slug} = await params
    return (
        <>
       <article>
        <h3>Blog Heading: {slug}</h3>
       </article>
        </>
    )
}