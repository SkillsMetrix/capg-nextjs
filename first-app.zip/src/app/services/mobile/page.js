
 

export default function About(){

    return (
        <>
      <h1>Mobile Development</h1>
       
        </>
    )
}