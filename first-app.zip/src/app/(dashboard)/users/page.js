
 

export default function Home(){

    return (
        <>
        <h1>Dashboard Page</h1>
        <p>Welcome to our Admin APP</p>
        </>
    )
}