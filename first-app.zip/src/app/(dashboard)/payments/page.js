
 

export default function Home(){

    return (
        <>
         
        <p>Welcome to Payment Page of Dashboard</p>
        </>
    )
}