import styles from './Dashboard.module.css'
 

export default function DashBoardLayout({children}){

    return (
        <div>
            <header className={styles.header}>
                Dashboard Menu
            </header>
            <main>{children}</main>
        </div>
    )
}