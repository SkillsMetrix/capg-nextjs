import Navigation from "@/components/Navigation"

 
export const metadata={
    title: "My Routing App"
}

export default function RootLayout({children}){

    return (
        <html>
            <body>
               <Navigation/>
                <hr/>
                <main style={{padding:"20px"}}>{children}</main>
            </body>
        </html>
    )
}