'use client'
import { addProduct } from "@/services/productService";
import React, { useState } from "react";

function ProductForm(props) {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");

  async function saveProduct() {
    await addProduct({
      name,
      price: Number(price),
    });
    alert("product added");
    setName("");
    setPrice("");
  }
  return <div>
    <p>Product Application</p>
    <input placeholder="Enter Product name" value={name} onChange={(e)=> setName(e.target.value)}/>
    <input placeholder="Enter Product price" value={price} onChange={(e)=> setPrice(e.target.value)}/>
    <br/>
    <button onClick={saveProduct}>Add Product</button>
  </div>;
}

export default ProductForm;
