'use client'
import { getProducts } from '@/services/productService';
import React, { useEffect, useState } from 'react';

function ProductList(props) {
    const [products,setProducts]= useState([])
    useEffect(()=>{
        loadProducts()
    },[])
    async function loadProducts() {
        const data= await getProducts()
        setProducts(data)
    }
    return (
        <div>
            <p>Product List</p> 
            {products.map(product => (
                <div key={product.id}>
                    {product.name}- 💲{product.price}
                </div>
            ))}
        </div>
    );
}

export default ProductList;