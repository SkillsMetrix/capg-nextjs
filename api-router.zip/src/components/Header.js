import React from 'react';

function Header(props) {
    return (
        <div>
            API Route Application
        </div>
    );
}

export default Header;