import Header from "@/components/Header";
import ProductForm from "@/components/ProductForm";
import ProductList from "@/components/ProductList";

 

export default function Home(){

    return (
        <>
        <Header/>
        <ProductList/>
        <hr/>
        <ProductForm/>
        </>
    )
}