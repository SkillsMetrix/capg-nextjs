 

 
export const metadata={
    title: "My Routing App"
}

export default function RootLayout({children}){

    return (
        <html>
            <body>
               
                <hr/>
                <main style={{padding:"20px"}}>{children}</main>
            </body>
        </html>
    )
}