import { NextResponse } from "next/server";

const BASE_URL = "http://localhost:3001";

export async function GET() {
  const response = await fetch(`${BASE_URL}/products`);
  const data = await response.json();
  return NextResponse.json(data);
}

export async function POST(request) {
  const body = await request.json();

  const response = await fetch(`${BASE_URL}/products`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });

  const data = await response.json();
  return NextResponse.json(data, { status: 201 });
}
