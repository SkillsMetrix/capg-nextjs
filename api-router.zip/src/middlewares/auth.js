import { NextResponse } from "next/server";

export function auth(request) {
  const token = request.headers.get("token");
  console.log("recieved token ",token);
  
  if (token !== "12345") {
    return NextResponse.json(
      {
        success: false,
        message: "Invalid Token",
      },
      {
        status: 401,
      },
    );
  }
  return NextResponse.next()
}
