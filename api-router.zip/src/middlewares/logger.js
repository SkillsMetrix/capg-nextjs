import { NextResponse } from "next/server";

export function logger(request) {

  // on request  
  console.log("Method ", request.method);
  console.log("Path ", request.nextUrl.pathname);


}
