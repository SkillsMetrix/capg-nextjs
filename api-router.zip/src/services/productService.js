
export async function getProducts() {
    
    const response= await fetch("/api/products",{
      headers:{
        token:"12345"
      }
    })
    return await response.json()
}
export async function addProduct(product) {
    
      await fetch("/api/products",{
        method: "POST",
        headers: {
      "Content-Type": "application/json"
        },
        body: JSON.stringify(product)
    })
}
